# toDoList

## Para aprobar y promocionar
- ~~Cambiar turno.~~
- ~~Que la ficha sea redonda.~~
- ~~Que no se meta por otro lugar la ficha (en la matriz).~~
- ~~Mostrar quién está jugando.~~
- ~~Ajustar imagen al jugador que tiene el turno (mostrar SU imagen).~~
- ~~Verificar 4 en línea.~~
- ~~Timer general del juego.~~

## Opcionales promoción:

- ~~Mejorar diseño.~~
- ~~Mostrar GIF cuando alguno de los dos esté a punto de ganar.~~
- ~~Mostrar GIF y mensaje cuando alguien gane. GIF correspondiente a la fecha elegida.~~
- ~~Cambiar imagen no funciona.~~

## Mejoras para seguir desarrollando

Por cuestiones de tiempo no llegamos a implementar las siguientes features. 
A modo de posible continuación personal, externo a la materia:
- Timer personalizado
- Mostrar imagen dentro de las opciones del select.
- Timer para cada turno.
- Indicar con qué fichas se ganó.
